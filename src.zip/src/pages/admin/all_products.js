import React from "react";
import ProductTable from "../../components/product_table";

const AllProducts = () => {
  return (
    <div>
      <ProductTable />
    </div>
  );
};

export default AllProducts;
