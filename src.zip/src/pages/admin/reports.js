import React from "react";
import MultiStepForm from "../../components/multi_step_form";

const Reports = () => {
  return (
    <div>
      <MultiStepForm />
    </div>
  );
};

export default Reports;
