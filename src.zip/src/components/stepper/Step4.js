// src/steps/Step4.js
import React from 'react';

const Step4 = () => (
    <div className="flex flex-col md:flex-row">
        <p className="text-gray-600">Confirm your details and submit.</p>
    </div>
);

export default Step4;
